# 🌿 Verde Interior — Vault Obsidian
> Cole cada seção abaixo no arquivo correspondente dentro do seu vault. A estrutura de pastas está indicada no início de cada bloco.

---

# ESTRUTURA DO VAULT

```
Verde Interior/
├── 00 - Visão Geral/
│   ├── README.md                    ← índice do vault
│   ├── Arquitetura geral.md
│   └── Decisões importantes.md
│
├── 01 - Orçamentos/
│   ├── Status atual.md
│   └── Roadmap.md
│
├── 02 - Ponto Eletrônico/
│   ├── Status atual.md
│   └── Próximos passos.md
│
├── 03 - Ordem de Serviço/
│   ├── Status atual.md
│   └── Decisões pendentes.md
│
├── 04 - CRM Dashboard/
│   ├── Status atual.md
│   └── Roadmap.md
│
├── 05 - Plataforma Unificada/
│   └── Visão futura.md
│
├── 06 - Padrões Comuns/
│   ├── Design system.md
│   └── Estrutura de dados.md
│
└── 99 - Sessões com Claude/
    └── 2026-06-22 - Planejamento geral.md
```

---

# ARQUIVO: 00 - Visão Geral/README.md

```markdown
# Verde Interior — Central do Projeto

## O que é este vault
Documentação de todos os módulos e decisões do sistema interno da Verde Interior Paisagismo.
Atualizado ao final de cada sessão de desenvolvimento com Claude.

## Módulos

| Módulo | Status | Pasta local | Link rápido |
|---|---|---|---|
| Ponto Eletrônico | ✅ Produção | `apps/ponto/` | [[02 - Ponto Eletrônico/Status atual]] |
| Gerador de Orçamentos | 🟡 Melhorias pendentes | `tools/orcamentos/` | [[01 - Orçamentos/Status atual]] |
| Ordem de Serviço | 🟡 Adaptação mobile | `tools/ordem-de-servico/` | [[03 - Ordem de Serviço/Status atual]] |
| CRM / Dashboard | 🔴 Início | `apps/crm/` | [[04 - CRM Dashboard/Status atual]] |
| Plataforma Unificada | ⬜ Planejado | — | [[05 - Plataforma Unificada/Visão futura]] |

## Decisões abertas (urgentes)

- [ ] Sistema de fotos da OS: Opção A ou Opção B → [[03 - Ordem de Serviço/Decisões pendentes]]
- [ ] Formato do ID único de cliente → [[06 - Padrões Comuns/Estrutura de dados]]
- [ ] Status do orçamento como gatilho de OS → [[06 - Padrões Comuns/Estrutura de dados]]

## Última sessão
[[99 - Sessões com Claude/2026-06-22 - Planejamento geral]]
```

---

# ARQUIVO: 00 - Visão Geral/Decisões importantes.md

```markdown
# Decisões Importantes

Log cronológico de decisões estruturais. Nunca deletar — apenas adicionar.

---

## Junho 2026

### Estratégia: modular primeiro, unificar depois
**Data:** 22/06/2026
**Decisão:** Construir cada módulo separadamente com padrões comuns, unificar quando maduros.
**Motivo:** Escopo controlado, aprendizado incremental, erros contidos.
**Impacto:** Exige definir padrões visuais e de dados desde o início.

### Stack por tipo de módulo
**Data:** 22/06/2026
**Decisão:** HTML puro para tools simples (orçamentos, OS). React + Vite para apps com estado complexo (CRM). Supabase para apps com persistência (Ponto).
**Motivo:** Ferramentas simples não precisam de build system. Apps complexos precisam de estado e componentes.

### Não mudar sem discussão
- Paleta de cores (deriva do logo da empresa)
- Nomes dos funcionários (chaves no banco Supabase)
- Fluxo de ponto: entry → break → return → exit
- Lógica de banco de horas
- Credenciais Supabase
```

---

# ARQUIVO: 01 - Orçamentos/Status atual.md

```markdown
# Gerador de Orçamentos — Status Atual

**Arquivo:** `verde_interior_gerador_orcamento_10.html`
**Localização:** `tools/orcamentos/`
**Stack:** HTML único, offline, sem dependências externas
**Fontes:** Inter + Montserrat (Google Fonts)

---

## O que funciona

- Painel lateral (formulário) + preview em tempo real do documento
- Página 1: proposta comercial com tabela de itens, subtotais, condições
- Página 2: galeria de fotos (Anexo)
- Logo da Verde Interior embutido em base64
- Campo "AC:" (Aos Cuidados de) no cabeçalho
- Consultor visível apenas no painel interno, não no impresso
- Título do documento editável inline, duplo-clique para resetar

## 7 modelos de serviço

| Modelo | Regras especiais |
|---|---|
| Venda / Implantação | — |
| Reforma | — |
| Locação | Auto-ativa Manutenção Recorrente + Fidelidade obrigatória |
| Manutenção Recorrente | — |
| Manutenção Pontual | Opção de frequência Pontual |
| Eventos | Campos de entrega e retirada |
| Outros Serviços | — |

**Lógica de reposição:** Locação → trava em "ilimitado". Outros → toggle quantidade/ilimitado.

---

## Próxima ação

Escolher uma das três opções abaixo:

- **A)** Corrigir 3 bugs prioritários (rápido)
- **B)** Implementar 6 funcionalidades essenciais (resultado comercial imediato)
- **C)** Definir design system antes de evoluir (consistência com outros módulos)

Ver roadmap completo → [[01 - Orçamentos/Roadmap]]
```

---

# ARQUIVO: 01 - Orçamentos/Roadmap.md

```markdown
# Gerador de Orçamentos — Roadmap

## Bugs prioritários (3)
- [ ] 1. Geração de proposta vazia sem aviso ao usuário
- [ ] 2. Conflito de override no título ao editar
- [ ] 3. Reset incorreto do toggle de reposição de plantas

## Funcionalidades essenciais faltando (6)
- [ ] 4. Numeração automática de propostas
- [ ] 5. Salvamento de rascunho em localStorage
- [ ] 6. Data de validade automática
- [ ] 7. Desconto global
- [ ] 8. Campos de e-mail e telefone do cliente
- [ ] 9. Histórico mini de propostas

## Qualidade comercial (3)
- [ ] 10. Itens de cortesia / gratuitos
- [ ] 11. Opções A/B de proposta
- [ ] 12. Seção de termos editável

## UX (3)
- [ ] 13. Botão "limpar tudo"
- [ ] 14. Reordenar itens por drag-and-drop
- [ ] 15. Duplicar item

## Fase futura (5)
- [ ] 16. Exportação JSON
- [ ] 17. Banco de itens favoritos
- [ ] 18. Integração WhatsApp
- [ ] 19. PDF direto (sem print dialog)
- [ ] 20. Versionamento de propostas
```

---

# ARQUIVO: 02 - Ponto Eletrônico/Status atual.md

```markdown
# Ponto Eletrônico — Status Atual

**Status:** ✅ Produção
**URL:** https://verde-interior-pwa.vercel.app
**Repositório:** https://github.com/ferworks93-weed/verde-interior-pwa
**Stack:** Vite + JavaScript ES Modules + Supabase
**Banco:** Supabase — projeto `verde-interior-ponto`

---

## Equipe cadastrada

| Nome | Cargo | Contrato | Jornada | Usuário |
|---|---|---|---|---|
| Beto | Vendas | CLT | 8h | `beto` |
| Brenno | Consultor | PJ | 6h | `brenno` |
| Bruno | Designer | CLT | 8h | `bruno` |
| Carlos | TI | CLT | 8h | `carlos` |
| Greg | Estagiário | CLT | 8h | `greg` |
| Miriam | RH | CLT | 8h | `miriam` |
| Pedro Silva | Financeiro | CLT | 8h | `pedro` |
| Peterson | Arquiteto | CLT | 8h | `peterson` |
| Fernando | Gestor | — | — | `fernando` |

---

## O que funciona (colaborador)
- Bater ponto: entrada, intervalo, retorno, saída
- Geolocalização na entrada e saída
- Relógio ao vivo com data por extenso
- Espelho mensal com impressão
- Banco de horas: saldo, extras, devidas
- Justificativas com upload de anexos
- Notificações browser de lembrete
- Troca de senha

## O que funciona (gestor)
- Dashboard com 4 KPIs
- Tabela de status em tempo real
- Alertas automáticos (banco crítico, atraso)
- Edição de registros em qualquer data
- Mapa Leaflet com pins de entrada/saída
- Aprovação de justificativas
- Exportação CSV
- Adicionar/editar/remover colaboradores

---

## Arquitetura resumida

```
Frontend: HTML + CSS + JS ES Modules
Build: Vite
Backend: Supabase (PostgreSQL + Auth + Storage + Edge Functions)
Auth: email {username}@vi.app + senha
Deploy: Vercel (auto via GitHub push)
```

## Banco de dados (4 tabelas)
- `employees` — dados e métricas da equipe
- `profiles` — vínculo auth.user ↔ employee + role
- `punch_records` — registros de ponto com lat/lng
- `justifications` — ocorrências com anexos

---

## Próximos passos
- [ ] Reset de senha via e-mail (UI faltando)
- [ ] Gestor redefine senha de colaborador
- [ ] Exportação XLSX com SheetJS
- [ ] Relatório de frequência (faltas/atrasos por mês)
- [ ] Gráfico de evolução do banco de horas
- [ ] Auditoria: log de edições

## Não mudar sem discussão
- Paleta: verde `#2d5a1b` + vermelho `#7a1a1a`
- Fluxo de ponto: entry → break → return → exit
- Lógica `calcWork` / `calcWorkClosed`
- Credenciais Supabase
```

---

# ARQUIVO: 03 - Ordem de Serviço/Status atual.md

```markdown
# Ordem de Serviço — Status Atual

**Arquivo atual:** `plano-execucao-heimr_10.html` (versão Heimr Coworking)
**Localização:** `tools/ordem-de-servico/`
**Stack:** HTML único, offline, sem dependências externas
**Fontes:** Inter + Montserrat (Google Fonts)

---

## O que funciona (versão atual)

- Cabeçalho com dados do cliente e tipo de serviço
- Barra de info (data, responsável, tipo, status)
- Tabela de plantas com operações: Nova, Substituição, Preenchimento, Cortesia, Movimentação
- Lista de insumos técnicos em cards
- Roteiro de execução passo a passo com alertas críticos
- Sistema de fotos: tag de Momento (Antes/Depois) + Área (multiselect)
- Checklist de conclusão (14 itens)
- Assinatura do líder Verde Interior e responsável do cliente
- Campo de observações finais

## Situação atual
A OS existe e funciona na web. O layout mobile foi construído e aprovado visualmente. Falta tornar o acesso fluido para o colaborador usar no celular em campo.

---

## Próxima versão (em definição)

**Origem dos dados:** importados do orçamento aprovado + campos editáveis para complementar

**Decisão aberta sobre fotos:** → [[03 - Ordem de Serviço/Decisões pendentes]]

**Encerramento definido:**
- Assinatura digital ou campo de nome do cliente
- Campo de observações finais do colaborador
```

---

# ARQUIVO: 03 - Ordem de Serviço/Decisões pendentes.md

```markdown
# Ordem de Serviço — Decisões Pendentes

---

## ⚠️ Decisão aberta: sistema de fotos

### Opção A — Slots simples
Slots de "Antes" e "Depois" lado a lado por ambiente. Colaborador preenche na ordem que quiser.

**Prós:** mais rápido, sem risco de esquecer o modo
**Contras:** não garante que "Antes" seja tirado antes de começar o serviço

### Opção B — Dois modos (recomendada)
A OS abre no **Modo Execução**: slots de "Depois" ficam bloqueados. Ao concluir, muda para **Modo Conclusão**: "Antes" aparece ao lado do slot de "Depois" vazio.

**Prós:** garante o "Antes" em 100% dos serviços, material de marketing já pareado e organizado
**Contras:** um toque a mais (mudar de modo)

**Recomendação:** Opção B — o custo operacional é mínimo e o ganho para marketing é garantido.

> **Status:** aguardando decisão do Fernando

---

## Fluxo de integração com orçamento (futuro)

Quando integrado à plataforma:
1. Orçamento recebe status "Aprovado"
2. OS gerada automaticamente com dados do cliente, endereço, itens e valor
3. Campos editáveis para complementar informações de campo
4. Equipe designada vinculada ao cadastro de funcionários
```

---

# ARQUIVO: 04 - CRM Dashboard/Status atual.md

```markdown
# CRM / Dashboard — Status Atual

**Status:** 🔴 Início — estrutura criada, sem componentes implementados
**Stack:** React + JSX (Vite)
**Localização:** `apps/crm/`
**Deploy:** ainda não

---

## O que foi definido

**Funil Kanban (5 estágios):**
1. Novo Lead
2. Orçamento Enviado
3. Negociação
4. Aprovado
5. Não Aprovado (com motivo obrigatório)

**Motivos de perda (obrigatórios ao marcar "Não Aprovado"):**
- Preço Alto
- Concorrente Cobriu Oferta
- Opção por Plantas Artificiais
- Projeto Suspenso

**Campos do lead:** empresa, serviço (com badge por tipo), bairro, valor, canal de origem

---

## Próximos componentes a criar (backlog)

### Fase 1 — Funil visível
- [ ] `CRMContext.jsx` — estado global com dados simulados e função `moverLead()`
- [ ] `LeadCard` — nome, serviço (badge), bairro, valor, canal
- [ ] `KanbanColumn` — filtra por status, mostra contador
- [ ] `KanbanBoard` — organiza 5 colunas na horizontal

### Fase 2 — Gestão comercial
- [ ] `ModalOrcamento` — detalhe do lead + mudança de status
- [ ] Trava de motivo obrigatório ao marcar "não aprovado"

### Fase 3 — Pós-venda e logística
- [ ] Campos de contrato: início, vigência, reajuste, dia de faturamento
- [ ] `RoutePlanner` — roteirizador por bairro e frequência de visita
- [ ] Botão de solicitação de reposição de planta

---

## Tipos de serviço (para badges)
Locação, Manutenção Recorrente, Manutenção Pontual, Implantação, Reforma, Eventos, Outros
```

---

# ARQUIVO: 05 - Plataforma Unificada/Visão futura.md

```markdown
# Plataforma Unificada — Visão Futura

> Esta é a fase final do projeto. Acontece quando os módulos individuais estiverem maduros.

---

## Conceito

Hub central com login único que conecta todos os módulos. Dados de clientes, funcionários e histórico compartilhados. O colaborador acessa tudo em um só lugar.

## Fluxo de dados automático

```
Orçamento aprovado
  → gera OS automaticamente (cliente, itens, valor preenchidos)
    → equipe registra ponto vinculado à OS
      → financeiro calcula custo de mão de obra por OS
        → margem real de cada serviço no dashboard
```

## Módulos confirmados
- Orçamentos
- Ordem de Serviço
- Ponto Eletrônico
- Financeiro / Dashboard

## Módulos futuros identificados
- CRM de clientes (em construção)
- Banco de mídias (fotos Antes/Depois centralizadas para marketing)
- Relatórios gerenciais
- Portal do cliente (visualizar OS e aprovar serviços)

## Perfis de acesso

| Perfil | Acesso |
|---|---|
| Gestor | Total |
| Colaborador | OS, Ponto, Fotos |
| Cliente (futuro) | Ver OS, aprovar |

## Arquitetura técnica planejada
- CRM (React) como shell principal
- Outros módulos migram como rotas dentro do React
- Ponto integrado via API Supabase
- HTMLs autossuficientes migram para componentes React
- Login único via Supabase Auth

## Pré-requisitos antes de unificar
- [ ] ID único de cliente definido e implementado em todos os módulos
- [ ] Nomes de funcionários padronizados em todos os módulos
- [ ] Status do orçamento como gatilho de OS funcionando
- [ ] Design system visual aplicado em todos os módulos
```

---

# ARQUIVO: 06 - Padrões Comuns/Design system.md

```markdown
# Design System — Verde Interior

## Paleta de cores

| Nome | Hex | Uso |
|---|---|---|
| Verde escuro | `#1a3d22` | Cabeçalhos, botões primários |
| Verde médio | `#2d6a35` | Acentos, hover states |
| Verde bg | `#EAF3DE` | Fundos de cards, badges sucesso |
| Vermelho vinho | `#7a1f1f` | Ações destrutivas, alertas |
| Cinza quente | `#f5f4f0` | Fundo da página |
| Cinza texto | `#374151` | Texto principal |
| Cinza suave | `#6b7280` | Texto secundário |
| Borda | `#e5e7eb` | Cards e inputs |

## Status

| Status | Fundo | Texto |
|---|---|---|
| Concluído | `#EAF3DE` | `#27500A` |
| Em andamento | `#FAEEDA` | `#633806` |
| Atenção | `#FCEBEB` | `#791F1F` |
| Pendente | cinza suave | cinza texto |

## Tipografia
- **Títulos de documentos:** Montserrat, 700–800
- **UI geral:** Inter, 400–600
- **Tamanhos:** 22px título · 16px seção · 13–14px corpo · 11–12px meta

## Ícones
- Atual: Font Awesome 6.5 (Ponto) + emojis (OS)
- Padrão futuro: **Tabler Icons outline** (para unificação)

## Componentes padrão
Ver `padroes-comuns.md` na pasta `docs/` do projeto para código CSS.
```

---

# ARQUIVO: 06 - Padrões Comuns/Estrutura de dados.md

```markdown
# Estrutura de Dados — Verde Interior

## IDs (decisão pendente)

| Entidade | Formato proposto | Exemplo |
|---|---|---|
| Cliente | `CLI-NNN` | `CLI-001` |
| Orçamento | `ORC-NNN` | `ORC-042` |
| Ordem de Serviço | `OS-NNN` | `OS-042` |
| Funcionário | nome lowercase | `brenno` |

> ⚠️ Decisão pendente: confirmar formato e implementar em todos os módulos antes da unificação.

## Nomes dos funcionários (padrão fixo)

Usar exatamente estes nomes em todos os módulos:

`Beto` · `Brenno` · `Bruno` · `Carlos` · `Greg` · `Miriam` · `Pedro Silva` · `Peterson`

Não alterar sem verificar impacto no banco Supabase.

## Status do orçamento (proposta)

| Status | Ação gatilho |
|---|---|
| Rascunho | — |
| Enviado | — |
| **Aprovado** | **Gera OS automaticamente** |
| Não aprovado | Registrar motivo obrigatório |
| Cancelado | — |

> ⚠️ Decisão pendente: confirmar "Aprovado" como gatilho de OS.

## Regras de negócio

**Reposição de plantas:**
- Locação → reposição sempre "ilimitada" (campo travado)
- Outros → toggle quantidade ou ilimitado

**Modelos que auto-ativam Manutenção Recorrente:**
- Locação → auto-ativa MR + torna Fidelidade obrigatória

**Banco de horas:**
```
meta = jornada 8h → 176h/mês | jornada 6h → 132h/mês
saldo = minutos trabalhados − (jornada × 60)
```
```

---

# ARQUIVO: 99 - Sessões com Claude/2026-06-22 - Planejamento geral.md

```markdown
# Sessão — Planejamento Geral do Projeto
**Data:** 22 de junho de 2026
**Duração:** sessão longa
**Foco:** visão geral, estratégia, arquitetura, módulos

---

## O que foi discutido

### 1. Estratégia: modular primeiro, unificar depois
Decisão de construir módulos independentes com padrões comuns e unificar ao final. Risco principal: construir incompatíveis. Solução: padrões comuns definidos agora.

### 2. Obsidian como sistema de gestão
Limitação: sem integração direta com Claude. Fluxo: Claude gera Markdown → Fernando cola no vault. Plugins recomendados: Canvas, Excalidraw, Dataview, Tasks.

### 3. Estrutura de pastas definida
```
verde-interior/
├── apps/ponto/
├── apps/crm/
├── tools/orcamentos/
├── tools/ordem-de-servico/
└── docs/
```

### 4. Status dos módulos levantado
- Ponto: produção no Vercel + Supabase
- Orçamentos: funcionando, 20 melhorias mapeadas
- OS: funcionando na web, adaptação mobile pendente
- CRM: só estrutura, sem componentes

### 5. OS — escopo da próxima versão definido
- Dados importados do orçamento + editáveis
- Mobile-first para uso em campo
- Fotos Antes/Depois (decisão pendente: A ou B)
- Assinatura digital ou nome do cliente
- Observações finais do colaborador

### 6. Plataforma unificada — visão geral apresentada
- Hub central com login único
- Fluxo: orçamento → OS → ponto → financeiro
- CRM como shell principal na unificação

### 7. Arquivos analisados nesta sessão
- `verde_interior_gerador_orcamento_10.html`
- `plano-execucao-heimr_10.html`
- `HANDOFF.md` (Ponto Eletrônico)
- `handoff.md` (CRM)
- `index.html` (CRM shell)

---

## Decisões tomadas
- ✅ Estratégia modular confirmada
- ✅ Estrutura de pastas definida
- ✅ Escopo da próxima OS definido

## Decisões pendentes
- ⏳ Fotos da OS: Opção A ou B
- ⏳ Formato do ID único de cliente
- ⏳ Status "Aprovado" como gatilho de OS

## Próximas ações
- [ ] Criar estrutura de pastas no computador
- [ ] Criar este vault no Obsidian
- [ ] Decidir sobre fotos da OS (A ou B) para iniciar construção
- [ ] Escolher próxima frente: bugs do orçamento ou construção da OS
```
